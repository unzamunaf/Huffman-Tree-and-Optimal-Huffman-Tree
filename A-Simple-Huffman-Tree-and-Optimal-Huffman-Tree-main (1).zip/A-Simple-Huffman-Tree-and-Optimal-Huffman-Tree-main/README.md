# A-Simple-Huffman-Tree-and-Optimal-Huffman-Tree
 huffman tree is a way to compress a text that is stored in bits
